﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbanhang
{
    class HoaDonDTO
    {
        private int mahd;
        private int makh;
        private DateTime ngaylap;
        private long tongtien;

        public int MaHD
        {
            get { return mahd; }
            set { mahd = value; }
        }
        public int MaKH
        {
            get { return makh; }
            set { makh = value; }
        }
        public DateTime NgayLap
        {
            get { return ngaylap; }
            set { ngaylap = value; }
        }
        public long TongTien
        {
            get { return tongtien; }
            set { tongtien = value; }
        }
    }
}
