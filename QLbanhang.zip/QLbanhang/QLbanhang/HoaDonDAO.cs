﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace QLbanhang
{
    class HoaDonDAO
    {
        DataConnection dc;
        SqlDataAdapter da;
        SqlCommand cmd;

        public HoaDonDAO()
        {
            dc = new DataConnection();
        }

        public DataTable DanhSachHD()
        {
            String sql = "Select hd.MaHD, hd.MAKH, hd.NgayLap, hd.TongTien from HoaDon hd";
            SqlConnection con = dc.getConnect();

            da = new SqlDataAdapter(sql, con);

            con.Open();

            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public bool Them(HoaDonDTO hd)
        {
            String sql = "insert into HoaDon(MaHD, MaKH, NgayLap, TongTien) VALUES (@MaHD, @MaKH, @NgayLap, @TongTien)";
            SqlConnection con = dc.getConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@MaHD", SqlDbType.Int).Value = hd.MaHD.ToString();
                cmd.Parameters.Add("@MaKH", SqlDbType.Int).Value = hd.MaKH.ToString();
                cmd.Parameters.Add("@NgayLap", SqlDbType.DateTime).Value = hd.NgayLap;
                cmd.Parameters.Add("@TongTien", SqlDbType.Money).Value = hd.TongTien.ToString();
                cmd.ExecuteNonQuery();
                con.Close();
            }

            catch (Exception ex)
            {
                return false;
            }

            return true;
        }
    }
}
