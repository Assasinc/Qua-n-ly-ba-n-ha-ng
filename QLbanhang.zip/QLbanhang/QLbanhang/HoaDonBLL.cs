﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace QLbanhang
{
    class HoaDonBLL
    {
        HoaDonDAO hddao;

        public HoaDonBLL()
        {
            hddao = new HoaDonDAO();
        }
        public DataTable DanhSachHD()
        {
            return hddao.DanhSachHD();
        }
        public bool ThemHoaDon(HoaDonDTO hd)
        {
            return hddao.Them(hd);
        }
    }
}
