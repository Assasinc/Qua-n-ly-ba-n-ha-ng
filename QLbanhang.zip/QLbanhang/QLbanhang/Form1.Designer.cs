﻿namespace QLbanhang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MaHD = new System.Windows.Forms.Label();
            this.MaKH = new System.Windows.Forms.Label();
            this.NgayLap = new System.Windows.Forms.Label();
            this.TongTien = new System.Windows.Forms.Label();
            this.ThemHD = new System.Windows.Forms.Label();
            this.MaHD_Text = new System.Windows.Forms.TextBox();
            this.MaKH_Text = new System.Windows.Forms.TextBox();
            this.TongTien_Text = new System.Windows.Forms.TextBox();
            this.Tao = new System.Windows.Forms.Button();
            this.Huy = new System.Windows.Forms.Button();
            this.ViewHD = new System.Windows.Forms.DataGridView();
            this.NgayLap_Date = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.ViewHD)).BeginInit();
            this.SuspendLayout();
            // 
            // MaHD
            // 
            this.MaHD.AutoSize = true;
            this.MaHD.Location = new System.Drawing.Point(31, 91);
            this.MaHD.Name = "MaHD";
            this.MaHD.Size = new System.Drawing.Size(68, 13);
            this.MaHD.TabIndex = 0;
            this.MaHD.Text = "Mã Hóa Đơn";
            this.MaHD.Click += new System.EventHandler(this.MaHD_Click);
            // 
            // MaKH
            // 
            this.MaKH.AutoSize = true;
            this.MaKH.Location = new System.Drawing.Point(31, 144);
            this.MaKH.Name = "MaKH";
            this.MaKH.Size = new System.Drawing.Size(85, 13);
            this.MaKH.TabIndex = 1;
            this.MaKH.Text = "Mã Khách Hàng";
            this.MaKH.Click += new System.EventHandler(this.MaKH_Click);
            // 
            // NgayLap
            // 
            this.NgayLap.AutoSize = true;
            this.NgayLap.Location = new System.Drawing.Point(31, 203);
            this.NgayLap.Name = "NgayLap";
            this.NgayLap.Size = new System.Drawing.Size(53, 13);
            this.NgayLap.TabIndex = 2;
            this.NgayLap.Text = "Ngày Lập";
            this.NgayLap.Click += new System.EventHandler(this.NgayLap_Click);
            // 
            // TongTien
            // 
            this.TongTien.AutoSize = true;
            this.TongTien.Location = new System.Drawing.Point(31, 257);
            this.TongTien.Name = "TongTien";
            this.TongTien.Size = new System.Drawing.Size(56, 13);
            this.TongTien.TabIndex = 3;
            this.TongTien.Text = "Tổng Tiền";
            // 
            // ThemHD
            // 
            this.ThemHD.AutoSize = true;
            this.ThemHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThemHD.Location = new System.Drawing.Point(285, 18);
            this.ThemHD.Name = "ThemHD";
            this.ThemHD.Size = new System.Drawing.Size(187, 25);
            this.ThemHD.TabIndex = 4;
            this.ThemHD.Text = "THÊM HÓA ĐƠN";
            // 
            // MaHD_Text
            // 
            this.MaHD_Text.Location = new System.Drawing.Point(148, 88);
            this.MaHD_Text.Name = "MaHD_Text";
            this.MaHD_Text.Size = new System.Drawing.Size(225, 20);
            this.MaHD_Text.TabIndex = 5;
            // 
            // MaKH_Text
            // 
            this.MaKH_Text.Location = new System.Drawing.Point(148, 141);
            this.MaKH_Text.Name = "MaKH_Text";
            this.MaKH_Text.Size = new System.Drawing.Size(225, 20);
            this.MaKH_Text.TabIndex = 6;
            // 
            // TongTien_Text
            // 
            this.TongTien_Text.Location = new System.Drawing.Point(148, 254);
            this.TongTien_Text.Name = "TongTien_Text";
            this.TongTien_Text.Size = new System.Drawing.Size(225, 20);
            this.TongTien_Text.TabIndex = 8;
            // 
            // Tao
            // 
            this.Tao.Location = new System.Drawing.Point(290, 387);
            this.Tao.Name = "Tao";
            this.Tao.Size = new System.Drawing.Size(76, 34);
            this.Tao.TabIndex = 9;
            this.Tao.Text = "TẠO";
            this.Tao.UseVisualStyleBackColor = true;
            this.Tao.Click += new System.EventHandler(this.Tao_Click);
            // 
            // Huy
            // 
            this.Huy.Location = new System.Drawing.Point(414, 387);
            this.Huy.Name = "Huy";
            this.Huy.Size = new System.Drawing.Size(75, 34);
            this.Huy.TabIndex = 10;
            this.Huy.Text = "HỦY";
            this.Huy.UseVisualStyleBackColor = true;
            this.Huy.Click += new System.EventHandler(this.Huy_Click);
            // 
            // ViewHD
            // 
            this.ViewHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViewHD.Location = new System.Drawing.Point(427, 88);
            this.ViewHD.Name = "ViewHD";
            this.ViewHD.Size = new System.Drawing.Size(328, 226);
            this.ViewHD.TabIndex = 11;
            // 
            // NgayLap_Date
            // 
            this.NgayLap_Date.Location = new System.Drawing.Point(148, 197);
            this.NgayLap_Date.Name = "NgayLap_Date";
            this.NgayLap_Date.Size = new System.Drawing.Size(200, 20);
            this.NgayLap_Date.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.NgayLap_Date);
            this.Controls.Add(this.ViewHD);
            this.Controls.Add(this.Huy);
            this.Controls.Add(this.Tao);
            this.Controls.Add(this.TongTien_Text);
            this.Controls.Add(this.MaKH_Text);
            this.Controls.Add(this.MaHD_Text);
            this.Controls.Add(this.ThemHD);
            this.Controls.Add(this.TongTien);
            this.Controls.Add(this.NgayLap);
            this.Controls.Add(this.MaKH);
            this.Controls.Add(this.MaHD);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.ViewHD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MaHD;
        private System.Windows.Forms.Label MaKH;
        private System.Windows.Forms.Label NgayLap;
        private System.Windows.Forms.Label TongTien;
        private System.Windows.Forms.Label ThemHD;
        private System.Windows.Forms.TextBox MaHD_Text;
        private System.Windows.Forms.TextBox MaKH_Text;
        private System.Windows.Forms.TextBox TongTien_Text;
        private System.Windows.Forms.Button Tao;
        private System.Windows.Forms.Button Huy;
        private System.Windows.Forms.DataGridView ViewHD;
        private System.Windows.Forms.DateTimePicker NgayLap_Date;
    }
}

