﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLbanhang
{
    public partial class Form1 : Form
    {
        HoaDonBLL hdbll;
        public Form1()
        {
            InitializeComponent();
            hdbll = new HoaDonBLL();
            HienThi();
        }

        public void HienThi()
        {
            DataTable dt = hdbll.DanhSachHD();
            ViewHD.DataSource = dt;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThi();
        }
        private void MaHD_Click(object sender, EventArgs e)
        {

        }

        private void NgayLap_Click(object sender, EventArgs e)
        {

        }

        private void MaKH_Click(object sender, EventArgs e)
        {

        }

        private void NgayLap_Text_TextChanged(object sender, EventArgs e)
        {

        }

        private void Tao_Click(object sender, EventArgs e)
        {
            TaoHoaDon();
            HienThi();
        }
        public bool KiemTraHD()
        {
            if (String.IsNullOrEmpty(MaHD_Text.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã Hóa Đơn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaHD_Text.Focus();
                return false;
            }

            if (String.IsNullOrEmpty(MaKH_Text.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã Khách Hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaKH_Text.Focus();
                return false;
            }           
            if (String.IsNullOrEmpty(TongTien_Text.Text))
            {
                MessageBox.Show("Bạn chưa nhập Mã Khách Hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TongTien_Text.Focus();
                return false;
            }          
            return true;
        }
        public void TaoHoaDon()
        {
            if (KiemTraHD())
            {
                HoaDonDTO hd = new HoaDonDTO();
                hd.MaHD = int.Parse(MaHD_Text.Text);
                hd.MaKH = int.Parse(MaKH_Text.Text);
                hd.NgayLap = NgayLap_Date.Value;
                hd.TongTien = long.Parse(TongTien_Text.Text);
                if (hdbll.ThemHoaDon(hd))
                {
                    HienThi();
                    MessageBox.Show("Thêm thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Có lỗi xảy ra, xi thử lại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void Huy_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
